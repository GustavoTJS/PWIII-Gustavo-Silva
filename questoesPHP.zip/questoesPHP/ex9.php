<?php
echo "Exercício 9 <br>";
for ($n = 101; $n <= 110; $n++) {
    echo $n . "\n";
}

?>