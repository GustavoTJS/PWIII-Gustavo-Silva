<?php
echo "Exercício 7 <br>";
for ($n = 1; $n <= 10; $n++) {
    echo $n . "\n";
}
?>