<?php
echo "Exercício 10 <br>";
?>