<?php
echo "Exercício 8 <br>";
for ($n = 10; $n >= 1; $n--) {
    echo $n . "\n";
}
?>