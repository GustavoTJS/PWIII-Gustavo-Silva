<?php
$valor = 60;
$porc = $valor * 0.15;

echo "O valor dos 15% é de: ", $porc;


?>