<?php

$v1 = 5;
$v2 = 3;
$v3 = 10;

$media = ($v1+$v2+$v3) / 3;
echo "A media da soma das três variáveis é ",$media;

?>